int valor;
int valor2;

write "Informe um valor:";
read valor;

if (valor == valor2)
begin
    write "Impressao interna ao IF!\n";
end