int valor;

write "Informe um valor:";
read valor;

if (1 - 1)
begin
    write "O valor do teste eh VERDADEIRO!\n";
end
else
begin
    write "O valor eh teste eh FALSO!\n";
end